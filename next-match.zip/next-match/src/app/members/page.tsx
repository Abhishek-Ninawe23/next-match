import Link from "next/link"

const MembersPage = () => {
    return (
        <div>
            <h3 className="text-3xl">This will be the Members page</h3>
            <Link href='/'>Go back home</Link>
        </div>
    )
}
export default MembersPage