'use server';

import { prisma } from "@/lib/prisma";
import { registerSchemas, RegisterSchemas } from "@/lib/schemas/registerSchemas";
import bcrypt from "bcryptjs";

export async function registerUser(data: RegisterSchemas) {

    const validated = registerSchemas.safeParse(data);

    if (!validated.success) {
        return { error: validated.error }
    }

    const { name, email, password } = validated.data;

    const hashedPassword = await bcrypt.hash(password, 10);

    const existingUser = await prisma.user.findUnique({ where: { email } })

    if (existingUser) return { error: 'User already exists' };

    return prisma.user.create({
        data: {
            name,
            email,
            passwordhash: hashedPassword,
        },
    });

}