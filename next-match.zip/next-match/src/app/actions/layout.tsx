export const runtime = "nodejs";

export default function ActionsLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    return <>{children}</>;
}
