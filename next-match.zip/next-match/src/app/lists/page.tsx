const ListPage = () => {
    return (
        <div>ListPage</div>
    )
}
export default ListPage