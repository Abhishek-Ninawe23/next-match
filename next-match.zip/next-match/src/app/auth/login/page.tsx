import LoginFrom from "./LoginFrom"

const LoginPage = () => {
    return (
        <div className="flex items-center justify-center vertical-center">
            <LoginFrom />
        </div>
    )
}
export default LoginPage